---
name: tubeonai-repurpose
description: This skill should be used when the user wants to repurpose YouTube videos into social media content (LinkedIn post, Instagram Carousel, Instagram Reels, Facebook post, TikTok script, YouTube Shorts script) using the TubeonAI API, with email list CTAs to grow subscribers via Encharge.
---

# TubeonAI YouTube Repurpose Pipeline

Repurpose any YouTube video into 6 platform-specific social media formats using the TubeonAI API. Every piece of content includes a CTA to grow the user's email list via Encharge.

## Output Formats

- LinkedIn Post
- Instagram Carousel (7 slides)
- Instagram Reels Script (30-60s)
- Facebook Post
- TikTok Video Script (30-60s)
- YouTube Shorts Script (<60s)

## Setup (first time only)

### 1. Copy scripts into the project folder

Copy all files from this skill's `scripts/` directory into the user's project folder.

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Configure API keys

Create a `.env` file in the project folder:

```
TUBEONAI_API_KEY=your_tubeonai_api_key_here
ENCHARGE_API_KEY=your_encharge_api_key_here
```

- TubeonAI key format: `toai_sk_...` — get it from https://app.tubeonai.com/developer
- Encharge key — get it from Encharge account settings

### 4. Add to `.gitignore`

```
.env
prompt_ids.json
*.txt
```

## Usage

```bash
# Repurpose a video
python main.py "https://www.youtube.com/watch?v=VIDEO_ID"

# Repurpose + add a subscriber to Encharge
python main.py "https://www.youtube.com/watch?v=VIDEO_ID" --add-subscriber email@example.com
```

## How It Works

1. **One-time prompt setup**: On first run, `main.py` creates 6 saved prompts in TubeonAI (one per platform) and stores their IDs in `prompt_ids.json`. Subsequent runs skip this step.
2. **Summarise**: Submits the YouTube URL to TubeonAI and polls until the summary is ready.
3. **Repurpose**: Calls TubeonAI's repurpose endpoint once per platform using the saved `prompt_id`. Each platform gets a unique prompt ID — this avoids TubeonAI's cache returning identical content for all platforms.
4. **Save**: Writes all 6 content pieces to a `.txt` file named after the video title.
5. **Encharge** (optional): Adds the provided email to the Encharge list with tags `social-content` and `youtube-repurpose`.

## Scripts

| File | Purpose |
|------|---------|
| `main.py` | Entry point — orchestrates the full pipeline |
| `tubeonai_client.py` | TubeonAI API client (summaries, prompts, repurpose) |
| `encharge_client.py` | Encharge API client (add/update subscribers) |
| `prompts.py` | Platform-specific repurpose prompts with email CTA |
| `requirements.txt` | Python dependencies (`requests`, `python-dotenv`) |

## Customising Prompts

To change tone or style for any platform, edit `prompts.py`. The `PLATFORMS` dict has one entry per platform with a `prompt` field. The `CTA` variable at the top controls the email list call-to-action appended to every prompt.

After editing prompts, delete `prompt_ids.json` and rerun to recreate them in TubeonAI.

## Troubleshooting

- **Same content for all platforms**: Ensure `prompt_id` (not inline `prompt`) is used in the repurpose call. Delete `prompt_ids.json` and rerun to recreate prompts.
- **404 on repurpose poll**: Use the `_links.check_status` URL from the repurpose response, not the `prompt_id`.
- **422 on list_prompts**: Do not pass `source` as a query param — the TubeonAI API rejects it. Pass only `limit`.
- **Python < 3.9**: Avoid `list[str]` type hints — use plain `list` or omit the annotation.
