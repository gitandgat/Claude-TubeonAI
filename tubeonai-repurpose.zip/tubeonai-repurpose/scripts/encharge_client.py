import requests


BASE_URL = "https://api.encharge.io/v1"


class EnchargeClient:
    def __init__(self, api_key: str):
        self.session = requests.Session()
        self.session.headers.update({"X-Encharge-Token": api_key})

    def add_subscriber(self, email: str, name: str = "", tags=None) -> dict:
        """Add or update a subscriber in Encharge."""
        payload = {"email": email}
        if name:
            payload["name"] = name
        if tags:
            payload["tags"] = tags

        resp = self.session.post(f"{BASE_URL}/people", json={"person": payload})
        resp.raise_for_status()
        return resp.json()
