"""
Platform-specific repurpose prompts.
Each prompt tells TubeonAI exactly what to generate.
All prompts include an email list CTA to drive subscribers.
"""

CTA = "End with a CTA inviting readers to join the free email list for more exclusive insights like this."

PLATFORMS = {
    "linkedin": {
        "label": "LinkedIn Post",
        "format": "linkedin",
        "prompt": (
            "Write a compelling LinkedIn post from this content. "
            "Start with a strong hook (first line must stop the scroll). "
            "Use short paragraphs, line breaks for readability, and 3-5 relevant hashtags. "
            "Keep it under 1300 characters. "
            + CTA
        ),
    },
    "instagram_carousel": {
        "label": "Instagram Carousel",
        "format": "custom",
        "prompt": (
            "Create a 7-slide Instagram carousel from this content. "
            "Slide 1: Bold hook/title that makes people swipe. "
            "Slides 2-6: One key insight per slide — short headline + 1-2 sentence explanation. "
            "Slide 7: Summary + " + CTA + " "
            "Format each slide as: [Slide N] Headline\\nBody text."
        ),
    },
    "reels": {
        "label": "Instagram Reels Script",
        "format": "custom",
        "prompt": (
            "Write a 30-60 second Instagram Reels video script from this content. "
            "Structure: Hook (0-3s) → 3 punchy key points → Call to action. "
            "Use casual, conversational language. Include [VISUAL CUE] directions. "
            + CTA
        ),
    },
    "facebook": {
        "label": "Facebook Post",
        "format": "custom",
        "prompt": (
            "Write an engaging Facebook post from this content. "
            "Start with a relatable question or bold statement. "
            "Tell a short story or share the key insight in plain language. "
            "Keep it warm and conversational (200-400 words). "
            + CTA
        ),
    },
    "tiktok": {
        "label": "TikTok Video Script",
        "format": "custom",
        "prompt": (
            "Write a 30-60 second TikTok video script from this content. "
            "Open with a pattern interrupt hook in the first 2 seconds. "
            "Deliver value fast — one main insight with a surprising angle. "
            "Close with a curiosity-driven CTA. Use casual Gen-Z friendly language. "
            "Include [ON SCREEN TEXT] and [VISUAL] directions. "
            + CTA
        ),
    },
    "youtube_shorts": {
        "label": "YouTube Shorts Script",
        "format": "custom",
        "prompt": (
            "Write a YouTube Shorts script (under 60 seconds) from this content. "
            "Hook: Start mid-action or with a bold claim — no intro. "
            "Body: 2-3 fast-paced key points with concrete examples. "
            "End screen CTA: Subscribe + join the email list. "
            "Include [VISUAL] directions and keep sentences short and punchy. "
            + CTA
        ),
    },
}
